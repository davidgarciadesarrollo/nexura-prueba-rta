<?php
define('DB_HOST', 'localhost');
define('DB_DATABASE', 'nexura_b_d');
define('DB_USER', 'root');
define('DB_PASSWORD', '');